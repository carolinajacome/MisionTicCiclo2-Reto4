package co.edu.utp.misiontic2022.c2.cjacome.controller;

import java.sql.SQLException;

import java.util.List;

import co.edu.utp.misiontic2022.c2.cjacome.model.dao.ComprasDeLiderDao;
import co.edu.utp.misiontic2022.c2.cjacome.model.dao.DeudasPorProyectoDao;
import co.edu.utp.misiontic2022.c2.cjacome.model.dao.ProyectoBancoDao;

import co.edu.utp.misiontic2022.c2.cjacome.model.vo.ProyectoBancoVo;
import co.edu.utp.misiontic2022.c2.cjacome.model.vo.ComprasDeLiderVo;
import co.edu.utp.misiontic2022.c2.cjacome.model.vo.DeudasPorProyectoVo;


//CONTROLADOR:
    

public class ReportesController {
    private  ProyectoBancoDao requerimiento_1Dao;
    private DeudasPorProyectoDao requerimiento_2Dao;
    private   ComprasDeLiderDao requerimiento_3Dao;
 
 public ReportesController(){
 
     this.requerimiento_1Dao= new ProyectoBancoDao();
     this.requerimiento_2Dao= new DeudasPorProyectoDao();
     this.requerimiento_3Dao= new ComprasDeLiderDao();

 }
 
 public List<ProyectoBancoVo> consultarproyectosFinanciadosPorBanco(String banco) throws SQLException{
     return this.requerimiento_1Dao.consultarproyectosFinanciadosPorBanco( banco);
 }
 
 public List<DeudasPorProyectoVo> consultarDeudasPorProyecto(Double limiteinferior) throws SQLException{
     return this.requerimiento_2Dao.totalAdeudadoPorProyectosSuperioresALimite(limiteinferior);
 }

 public List <ComprasDeLiderVo> listarProyectosLideresQuemasgastan() throws SQLException{
    return requerimiento_3Dao.lideresQueMasGastan();
}

}
