package co.edu.utp.misiontic2022.c2.cjacome;

import co.edu.utp.misiontic2022.c2.cjacome.controller.ReportesController2;
import co.edu.utp.misiontic2022.c2.cjacome.model.dao.DeudasPorProyectoDao;
//import co.edu.utp.misiontic2022.c2.cjacome.model.dao.ProyectoBancoDao;
import co.edu.utp.misiontic2022.c2.cjacome.model.vo.DeudasPorProyectoVo;
import co.edu.utp.misiontic2022.c2.cjacome.view.ReportesView;
//import co.edu.utp.misiontic2022.c2.cjacome.model.dao.ProyectosDao;
//import co.edu.utp.misiontic2022.c2.cjacome.model.vo.ProyectosVo;
//import co.edu.utp.misiontic2022.c2.cjacome.view.ReportesView;
import co.edu.utp.misiontic2022.c2.cjacome.view.ReportesView2;

import java.sql.SQLException;

import co.edu.utp.misiontic2022.c2.cjacome.util.JDBCUtilities;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        var reportesview= new ReportesView();
        reportesview.proyectosFinanciadosPorBanco("Conavi");

        var view2 = new ReportesView();
        view2.totalAdeudadoPorProyectosSuperioresALimite(50_000d);

        var view3 = new ReportesView();
        view3.lideresQueMasGastan();
        /*
        //reportesview:
       // var view = new ReportesView2();
        var view1 = new ReportesView2();
        var view2 = new ReportesView2();
        var view3 = new ReportesView2();
      //  view.imprimirProyectosSinCasaCampestreNiCondominio();
        view1.proyectosFinanciadosPorBanco("Conavi");
        view2.requerimiento2(50_000d);
        view3.requerimiento3();

*/
       // view.imprimirlideresQueMasGastan();
        //try{
          //  var conn= JDBCUtilities.getConnection();
            //System.out.println("Conexión exitosa");
            //conn.close();
          // var pd= new ProyectosDao();
           
         // var pd= new ReportesController2();
         //var pd= new DeudasPorProyectoDao();
          //var lista=pd.listarProyectos("Casa Campestre", "Condominio");
         // var lista= pd.listarProyectosExcluyendoClasicaciones("Casa Campestre", "Condominio");
        
        
        // var lista=pd.totalAdeudadoPorProyectosSuperioresALimite(50.000);
         // var lista=pd.
         /*
           for (DeudasPorProyectoVo proyecto: lista){
            System.out.println(proyecto);
           }

        } catch( SQLException e){
            System.out.println("Error"+e);
         }
*/
    }
}
